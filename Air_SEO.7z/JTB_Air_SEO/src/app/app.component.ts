import { Component, OnInit, ViewEncapsulation, PLATFORM_ID, Inject, NgZone} from '@angular/core';
import { isPlatformBrowser, isPlatformServer } from '@angular/common';
import { TransferState } from '../modules/transfer-state/transfer-state';
import { REQUEST } from '@nguniversal/express-engine/tokens';


import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { MapsAPILoader } from '@agm/core';
import { } from 'googlemaps';


import * as $ from 'jquery'; // in the component
declare let google: any;
@Component({
  selector: 'demo-app',
//   template: `
//   <h1>{{ title }}</h1>
  
//   <!-- this creates a google map on the page with the given lat/lng from -->
//   <!-- the component as the initial center of the map: -->
// public latitude: number;
//   <agm-map [latitude]="latitude" [longitude]="longitude" [zoom]="5">
//   </agm-map>
//     <a routerLink="/">Home</a>
//     <a routerLink="/lazy">Lazy</a>
//     <router-outlet></router-outlet>
//   `,
    templateUrl: './app.component.html',
    styles: [
        require('../styles/styles.css'), 
        require('../styles/ovsfit-common_seo.css'),
        require('../styles/ovsair-region.css')
    ],
    encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
    
  constructor(private cache: TransferState, @Inject(PLATFORM_ID) private platformId: Object,
  private mapsAPILoader: MapsAPILoader,
  private $http : Http
) { }
public latitude: number;
public longitude: number;
public zoom: number;
public sample:any;

    title: string = 'My first AGM project';
    lat: number = 51.678418;
    lng: number = 7.809007;
  ngOnInit() {
    // This is an example

    // let geocoder = new google.maps.Geocoder();
    // geocoder.geocode({'address': 'India'}, function(results, status) {
    //     if (status === 'OK') {
    //         // resultsMap.setCenter(results[0].geometry.location);
    //         console.log(results[0].geometry.location);
    //     } else {
    //         alert('Geocode was not successful for the following reason: ' + status);
    //     }
    // });

    this.$http.get('http://maps.google.com/maps/api/geocode/json?address=India')
      .map((res:Response) => res.json())
      .subscribe(data => {

          this.sample = data.results[0].geometry.location;
          this.latitude = data.results[0].geometry.location.lat;
          this.longitude = data.results[0].geometry.location.lng;
          console.log(this.sample);
      });


    this.cache.set('message', 'Hello World');
    if (isPlatformBrowser(this.platformId)) {
        // Client only code.
        $('body').addClass('riju');

    }
    if (isPlatformServer(this.platformId)) {
        // Server only code.
    }
  }
}
