import { NgModule, ApplicationRef } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';

// import { AppRoutingModule } from "./app.routes";
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HomeView } from './home/home-view.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { RegionComponent } from './region/region.component';
import { CarrieRankingList } from './shared/components/carrier-ranking/carrier-ranking-list.component';
import { CountryList } from './region/components/country-list.component';
import { CityList } from './region/components/city-list.component';
import { CountryComponent } from './country/country.component';

import { CSVServices } from './shared/services/csv-services';
import { RegionDataService } from "./shared/services/region.service.component";
import { AgmCoreModule } from '@agm/core';


import '../../node_modules/jquery';


@NgModule({
  imports: [
    CommonModule,
    HttpModule,
    RouterModule.forRoot([
      { path: ':region', component: RegionComponent },
      { path: ':region/:country', component: CountryComponent },
    ]),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyB5OniYP3ZRpY0C90UhGtF0ppTmnbxqS5Y'
    })
  ],
    providers: [
        CSVServices,
        RegionDataService
    ],
    declarations: [ 
        AppComponent, 
        HomeView,
        HeaderComponent,
        FooterComponent,
        RegionComponent,
        CarrieRankingList,
        CountryList,
        CityList,
        CountryComponent
    ],
  exports: [ AppComponent ]
})
export class AppModule {}
