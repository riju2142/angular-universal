import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';


const CSVDATA: string = `Carrier Name,Carrier Code,Carrier Logo,Origin,Destination,Origin code,Destination code,Fare,Direct/Connection flight,Trip Type,Destination Image,A110 (Region),Region rank,A120 (Country),Country rank,A130 (City),City rank,A140 (Route),A150 (Class),A180 (Airline),A190 (Airport)
All Nippon Airlines,NH,sample_nh.jpg,Tokyo,Paris,HND,CDG,510220,Direct,Round Trip,sample_paris.jpg,Europe,1,France,1,Paris,1,HND-CDG,Business class,ANA,CDG
Cathay Pacific,CX,sample_cx.jpg,Tokyo,Paris,NRT,CDG,110220,Direct,Round Trip,sample_paris.jpg,Europe,,France,6,Paris,2,,,,CDG
Cathay Pacific,CX,sample_cx.jpg,Tokyo,Nice,HND,NCE,100090,Connection,Round Trip,sample_nice.jpg,Europe,8,France,2,Nice,1,,,,
Cathay Pacific,CX,sample_cx.jpg,Tokyo,Lyon,HND,LYS,99670,Connection,Round Trip,sample_lyon.jpg,Europe,7,France,3,Lyon,1,,,,
Emirates,EK,sample_ek.jpg,Tokyo,London,HND,LHR,91865,Direct,Round Trip,sample_london.jpg,Europe,3,United Kingdom,1,London,1,HND-LHR,,Emirates,LHR
Cathay Pacific,CX,sample_cx.jpg,Tokyo,Rome,HND,FCO,92800,Connection,Round Trip,sampl_rome.jpg,Europe,2,Italy,1,Rome,1,HND-FCO,,,
Japan Airlines,JL,sample_jl.jpg,Tokyo,Beijing,HND,PEK,57557,Direct,Round Trip,sample_beijing.jpg,Asia,1,China,1,Beijing,1,HND-PEK,Business class,JAL,PEK`;

@Injectable()
export class CSVServices {

    csvUrl: string = 'http://localhost:4004/api/messages';

    constructor(private http : Http){}

    public fetchCSVData() {
        return this.http.get(this.csvUrl)
        .map((res:Response) => res.text());
    }

    // public fetchCarrierData(region, rank) {
    //     // return this.carrierData(CSVDATA, rank, region);
    //     return this.http.get(this.csvUrl)
    //     .map((res:Response) => res.text());
    // }


    // private extractData(csv, region) {
    //     console.log(csv);
    //     console.log(region);
    //     let lines = csv.split("\n"),
    //         result = [],
    //         status = 'region',
    //         headers = lines[0].split(",");
    //     if(status === 'region') {
    //         headers = headers.slice(0,13);
    //     }
    //     for(let i=1;i<lines.length;i++){
    //         let obj = {},
    //             currentline = lines[i].split(",");
    //         if(status === 'region' && currentline.indexOf(region) !== -1) {
    //             currentline = currentline.slice(0,13);
    //             for(let j=0;j<headers.length;j++) {
    //                 obj[headers[j]] = currentline[j];
    //             }
    //             result.push(obj);
    //         }
    //     }
    //     return result;
    // }


    // private readRegionCSV(csv, region) {
    //     let lines = csv.split("\n"),
    //         result = [],
    //         status = 'region',
    //         headers = lines[0].split(",");
    //     if(status === 'region') {
    //         headers = headers.slice(0,13);
    //     }
    //     for(let i=1;i<lines.length;i++){
    //         let obj = {},
    //             currentline = lines[i].split(",");
    //         if(status === 'region' && currentline.indexOf(region) !== -1) {
    //             currentline = currentline.slice(0,13);
    //             for(let j=0;j<headers.length;j++) {
    //                 obj[headers[j]] = currentline[j];
    //             }
    //             result.push(obj);
    //         }
    //     }
    //     return result;
    // }

    // private carrierData( csv: any, rank: number, region:string) {
    //     let lines = csv.split("\n"),
    //         result = [],
    //         getRankIndex,
    //         status = 'region',
    //         headers = lines[0].split(",");
    //     if(status === 'region') {
    //         headers = headers.slice(0,13);
    //     }
    //     for(var i=0;i<lines.length;i++){
    //         var obj = {};
    //         var currentline = lines[i].split(",");

    //         if(status === 'region' && currentline.indexOf(region) !== -1) {
    //             currentline = currentline.slice(0,13);
    //             if(headers.indexOf('Region rank') !== -1) {
    //                 getRankIndex = headers.indexOf('Region rank');
    //                 if(currentline[getRankIndex] === rank) {
    //                     for(var j=0;j<headers.length;j++) {
    //                         obj[headers[j]] = currentline[j];
    //                     }
    //                     result.push(obj);
    //                     return obj;
    //                 }

    //             }
    //         }
    //     }
    // }


    // private extractData(res: Response) {
    //     let csvData = res['_body'] || '';
    //     let allTextLines = csvData.split(/\r\n|\n/);
    //     let headers = allTextLines[0].split(',');
    //     let lines = [];

    //     for ( let i = 0; i < allTextLines.length; i++) {
    //         // split content based on comma
    //         let data = allTextLines[i].split(',');
    //         if (data.length == headers.length) {
    //             let tarr = [];
    //             for ( let j = 0; j < headers.length; j++) {
    //                 tarr.push(data[j]);
    //             }
    //             lines.push(tarr);
    //         }
    //     }
    //     this.csvData = lines;
    // }

    private handleError (error: any) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
            console.error(errMsg); // log to console instead
        return errMsg;
    }
    
}

