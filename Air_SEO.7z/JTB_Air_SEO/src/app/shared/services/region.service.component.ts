import { OnInit } from '@angular/core';

export class RegionDataService implements OnInit {

    constructor() {}

    ngOnInit() {}

    public fetchRegionData(csv: any, region: string, level: string) {
        let lines = csv.split("\n"),
            result = [],
            dataLevel = level === 'country' ? 'A120 (Country)' : 'A130 (City)',
            headers = lines[0].split(",");
        for(let i=1;i<lines.length;i++) {
            let obj = {},
                currentline = lines[i].split(",");
            if(headers.indexOf(dataLevel) !== -1 && currentline.indexOf(region) !== -1) {
                let regionIdx = headers.indexOf(dataLevel);
                let regionName = currentline[regionIdx];
                if(result.indexOf(regionName) === -1) {
                    result.push(regionName);
                }
            }
        }
        return result;
    }

    public fetchData(csv: any, region: string, level: string) {
        let lines = csv.split("\n"),
            result = [],
            tempArr = [],
            dataLevel = level === 'country' ? 'A120 (Country)' : 'A130 (City)',
            headers = lines[0].split(",");
        for(let i=1;i<lines.length;i++) {
            let obj = {},
                currentline = lines[i].split(",");
            if(headers.indexOf(dataLevel) !== -1 && currentline.indexOf(region) !== -1) {
                let regionIdx = headers.indexOf(dataLevel);
                let regionName = currentline[regionIdx];
                if(tempArr.indexOf(regionName) === -1) {
                    tempArr.push(regionName);
                    for(let j=0;j<headers.length;j++) {
                        obj[headers[j]] = currentline[j];
                    }
                    result.push(obj);
                }
            }
        }
        return result;
    } 

}
