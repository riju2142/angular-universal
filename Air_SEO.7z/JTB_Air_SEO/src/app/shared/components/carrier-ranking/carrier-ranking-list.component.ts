import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { CSVServices } from '../../services/csv-services';


@Component({
  selector: 'carrier-ranking-list',
  templateUrl: './carrier-ranking-list.component.html'
})
export class CarrieRankingList implements OnInit {

    csvData: any;
    sub: any;
    rankOne: object;
    rankTwo: object;
    rankThree: object;
    rankFour: object;
    rankFive: object;
    rankSix: object;
    rankSeven: object;
    rankEight: object;
    rankNine: object;
    rankTen: object;
    constructor( private dataService: CSVServices, private route: ActivatedRoute) {}

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            let region = params['region'],
                sizeObj = this.size(params),
                country,
                city;
            if(sizeObj === 2) {
                country = params['country'];
            } else if(sizeObj === 3) {
                country = params['country'];
                city = params['city'];
            }
            this.dataService.fetchCSVData().subscribe(data => {
                if(sizeObj === 1) {
                    this.rankOne = this.carrierData(data,'1', region);
                    this.rankTwo = this.carrierData(data,'2', region);
                    this.rankThree = this.carrierData(data,'3', region);
                    this.rankFour = this.carrierData(data,'4', region);
                    this.rankFive = this.carrierData(data,'5', region);
                    this.rankSix = this.carrierData(data,'6', region);
                    this.rankSeven = this.carrierData(data,'7', region);
                    this.rankEight = this.carrierData(data,'8', region);
                    this.rankNine = this.carrierData(data,'9', region);
                    this.rankTen = this.carrierData(data,'10', region);
                } else if(sizeObj === 2) {
                    this.rankOne = this.carrierData(data,'1', region, country);
                    this.rankTwo = this.carrierData(data,'2', region, country);
                    this.rankThree = this.carrierData(data,'3', region, country);
                    this.rankFour = this.carrierData(data,'4', region, country);
                    this.rankFive = this.carrierData(data,'5', region, country);
                    this.rankSix = this.carrierData(data,'6', region, country);
                    this.rankSeven = this.carrierData(data,'7', region, country);
                    this.rankEight = this.carrierData(data,'8', region, country);
                    this.rankNine = this.carrierData(data,'9', region, country);
                    this.rankTen =  this.carrierData(data,'10', region, country);
                } else if(sizeObj === 3) {
                    this.rankOne = this.carrierData(data,'1', region, country, city);
                    this.rankTwo = this.carrierData(data,'2', region, country, city);
                    this.rankThree = this.carrierData(data,'3', region, country, city);
                    this.rankFour = this.carrierData(data,'4', region, country, city);
                    this.rankFive = this.carrierData(data,'5', region, country, city);
                    this.rankSix = this.carrierData(data,'6', region, country, city);
                    this.rankSeven = this.carrierData(data,'7', region, country, city);
                    this.rankEight = this.carrierData(data,'8', region, country, city);
                    this.rankNine = this.carrierData(data,'9', region, country, city);
                    this.rankTen =  this.carrierData(data,'10', region, country, city);
                }
            });
        });
    }

    private carrierData( csv: any, rank: string, region:string, country:string = 'na', city:string = 'na') {
        let countryStatus = country === 'na' ? false : true;
        let cityStatus = city === 'na' ? false : true;
        let lines = csv.split("\n"),
            result = [],
            getRankIndex,
            status = 'region',
            headers = lines[0].split(",");
        for(var i=0;i<lines.length;i++){
            var obj = {};
            var currentline = lines[i].split(",");
            if(status === 'region' && currentline.indexOf(region) !== -1) {
                if(headers.indexOf('Region rank') !== -1 && headers.indexOf('Country rank') !== -1) {
                    if(!countryStatus && !cityStatus) {
                        getRankIndex = headers.indexOf('Region rank');
                        if(currentline[getRankIndex] === rank && currentline.indexOf(region) !== -1) {
                            for(var j=0;j<headers.length;j++) {
                                obj[headers[j]] = currentline[j];
                            }
                            return obj;
                        }
                    } else if(countryStatus && !cityStatus) {
                        getRankIndex = headers.indexOf('Country rank')
                        if(currentline[getRankIndex] === rank && currentline.indexOf(country) !== -1) {
                            for(let j=0;j<headers.length;j++) {
                                obj[headers[j]] = currentline[j];
                            }
                            return obj;
                        }
                    } else {
                        getRankIndex = headers.indexOf('City rank')
                        if(currentline[getRankIndex] === rank && currentline.indexOf(country) !== -1 && currentline.indexOf(city) !== -1) {
                            for(let j=0;j<headers.length;j++) {
                                obj[headers[j]] = currentline[j];
                            }
                            return obj;
                        }
                    }
                }
            }
        }
    }

    private size = function(obj) {
        let size = 0,
            key;
        for (key in obj) {
            if (obj.hasOwnProperty(key)) size++;
        }
        return size;
    }

}
