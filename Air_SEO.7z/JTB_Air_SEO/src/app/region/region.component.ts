import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { Meta, Title } from "@angular/platform-browser";
import { CSVServices } from '../shared/services/csv-services';


@Component({
  selector: 'region-contents',
  templateUrl: './region.component.html'
})
export class RegionComponent implements OnInit {

  csvData: any;
  sub: any;
  constructor(
    meta: Meta, title: Title, 
    private dataService: CSVServices,
    private route: ActivatedRoute
    ) {

    // title.setTitle('My Home Page');

    // meta.removeTag("name='author'");
    // meta.removeTag("name='keywords'");
    // meta.removeTag("name='description'");
    
    // meta.addTags([
    //   { name: 'author',   content: 'JTB Air home'},
    //   { name: 'keywords', content: 'angular seo, angular 4 universal, etc'},
    //   { name: 'description', content: 'This is my Angular SEO-based App' }
    // ]);
    
   }

    ngOnInit() {
        // console.log("test");
        this.sub = this.route.params.subscribe(params => {
            let region = params['region'];
            this.dataService.fetchCSVData().subscribe(data => {
                this.extractData(data, region);
            });
        });
    }

    private extractData(csv, region) {
        let lines = csv.split("\n"),
            result = [],
            status = 'region',
            headers = lines[0].split(",");
        if(status === 'region') {
            headers = headers.slice(0,13);
        }
        for(let i=1;i<lines.length;i++){
            let obj = {},
                currentline = lines[i].split(",");
            if(status === 'region' && currentline.indexOf(region) !== -1) {
                currentline = currentline.slice(0,13);
                for(let j=0;j<headers.length;j++) {
                    obj[headers[j]] = currentline[j];
                }
                result.push(obj);
            }
        }
        this.csvData = result;
    }
}
