import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute } from '@angular/router';

import { CSVServices } from '../../shared/services/csv-services';
import { RegionDataService } from '../../shared/services/region.service.component';

@Component({
  selector: 'city-list',
  templateUrl: './city-list.component.html'
})
export class CityList implements OnInit {

    sub: any;
    cityList: any;
    csvDatas: any;
    regionName: string;
    countryName: string;
    constructor( 
        private dataService: CSVServices,
        private route: ActivatedRoute,
        private regionData : RegionDataService
        ) {}

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            let region = params['region'];
            this.regionName = region;
            this.dataService.fetchCSVData().subscribe(data => {
                this.cityList = this.regionData.fetchRegionData(data, region, 'city');
                this.csvDatas = this.regionData.fetchData(data, region, 'city');
            });
        });
    }
}