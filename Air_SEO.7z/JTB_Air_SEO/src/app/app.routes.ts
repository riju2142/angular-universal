import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegionComponent } from './region/region.component';
import { HeaderComponent } from "./shared/header/header.component";
import { HomeView } from "./home/home-view.component";

const routes: Routes = [
  { path: '', component: HomeView, pathMatch: 'full'},
  { path: 'lazy', loadChildren: './+lazy/lazy.module#LazyModule'}
];
  
  @NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }