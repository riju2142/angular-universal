/**
 * Routes which are handled by Angular in Express
 */
export const ROUTES: string[] = [
  '/',
  '/:region',
  '/:region/:country'
];
